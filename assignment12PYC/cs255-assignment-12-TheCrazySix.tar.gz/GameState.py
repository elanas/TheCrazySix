from EventHandler import EventHandler


class GameState(EventHandler):

    def __init__(self):
        pass

    def render(self):
        pass

    def update(self, time):
        pass

    def event(self, event):
        pass
