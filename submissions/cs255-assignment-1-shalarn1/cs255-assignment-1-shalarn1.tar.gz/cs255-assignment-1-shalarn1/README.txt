Team Name: The Crazy Six
Sarika Halarnakar - shalarn1@jhu.edu
Assignment 1 - README

The program anim.py draws infinite line segments in different colors and links the previous line with the next line.